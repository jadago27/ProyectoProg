﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using Game1.Content.obj;
using System.Threading;
using System;
using System.IO;

namespace Game1
{
    public enum Estado { turnoJugador, turnoEnemigo, seleccionarCasilla, gameOver, menuInicio, creacionPersonaje};
    
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private bool nuevaPartida = false;

        public Estado estadoActual= Estado.menuInicio;
        KeyboardState keyboardState, lastKeyboardState;

        const int MAXOPCION = 2;

        Texture2D tile;
        Texture2D personaje;
        Texture2D esqueleto;
        Texture2D barbaro;
        SpriteFont fuente;

        

        Personaje pj = new Personaje();
        Enemigo enemigo = new Enemigo();

        Random rand = new Random();

        bool accion = true;
        int movimiento, filas = 720 / 40, columnas = 1280/40, cont=0, opcion=0, experiencia=0, iniciativa=0;
        string output = "", input="", nombreTurnoActual = "";

        Vector2 cursor = new Vector2(), posicion = new Vector2();


        string[] mapa =
        {
            "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
            "X                X             X",
            "X  P  S          X             X",
            "X                              X",
            "X           S                  X",
            "XXXXXX                         X",
            "X                X             X",
            "X                X             X",
            "X      XXXXXXXXXXXXXXXXX       X",
            "X                X             X",
            "X                X             X",
            "X                X             X",
            "X                              X",
            "X            S                 X",
            "X      X                       X",
            "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
            "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
            "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        };

        List<Rectangle> obstaculos = new List<Rectangle>();
        List<Enemigo> enemigos = new List<Enemigo>();

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            _graphics.PreferredBackBufferWidth = 1280;
            _graphics.PreferredBackBufferHeight = 720;
            _graphics.ApplyChanges();
            pj.CargarPersonaje("PJ");

            mapa = cargarMapa(rand.Next(1, 6));

            movimiento = pj.GetMovimiento();
            
            //Guardamos las posiciones que aparecen en el mapa
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (mapa[i][j] == 'X')
                        obstaculos.Add(new Rectangle(j * 40, i * 40, 40, 40));
                    if (mapa[i][j] == 'S')
                    {
                        enemigo = new Enemigo();
                        enemigo.CargarEnemigo("../../../Content/Enemigos/esqueleto.txt");
                        enemigos.Add(enemigo);
                        enemigos[cont].SetPosicion(j*40, i*40);
                        experiencia += enemigos[cont].GetExp();
                        cont++;
                    }
                    if (mapa[i][j] == 'B')
                    {
                        enemigo = new Enemigo();
                        enemigo.CargarEnemigo("../../../Content/Enemigos/barbaro.txt");
                        enemigos.Add(enemigo);
                        enemigos[cont].SetPosicion(j * 40, i * 40);
                        experiencia += enemigos[cont].GetExp();
                        cont++;
                    }
                    if (mapa[i][j] == 'A')
                    {
                        enemigo = new Enemigo();
                        enemigo.CargarEnemigo("../../../Content/Enemigos/arquero.txt");
                        enemigos.Add(enemigo);
                        enemigos[cont].SetPosicion(j * 40, i * 40);
                        experiencia += enemigos[cont].GetExp();
                        cont++;
                    }
                    if (mapa[i][j] == 'P')
                    {
                        pj.SetPosicion(j*40, i*40);
                        posicion = pj.GetPosicion();
                        cursor = pj.GetPosicion();
                    }
                       
                }
            }
            iniciativa = enemigos.Count;
            nombreTurnoActual = pj.GetNombre();
        }

        public string[] cargarMapa(int num)
        {
            StreamReader myFile;
            string[] lineas = new string[filas];
            string linea, fich = "../../../Content/Mapas/mapa_" + num + ".txt";
            if (File.Exists(fich))
            {
                myFile = File.OpenText(fich);
                for (int i = 0; i < 18; i++)
                {
                    linea = myFile.ReadLine();
                    if (linea != null)
                    {
                        linea = linea.Substring(1);
                        lineas[i] = (linea);
                    }
                }
                myFile.Close();
            }
            return lineas;
        }

        bool KeyPressed(Keys key) // Nos permite realizar una accion solo una vez al pulsar una tecla
        {
            return keyboardState.IsKeyDown(key) && lastKeyboardState.IsKeyUp(key);
        }

        public bool colisionMuro( float x, float y) //Comprueba si se choca contra un muro
        {
            bool colision=false;
            Rectangle rec, person = new Rectangle(pj.GetPosicionX(),pj.GetPosicionY(),40,40);

            foreach (Rectangle r in obstaculos)
            {
                if (r.Intersects(new Rectangle((int)x, (int)y, 40, 40)))
                {
                    colision = true;
                }
            }
            foreach (Enemigo e in enemigos)
            {
                rec = new Rectangle(e.GetPosicionX(), e.GetPosicionY(), 40, 40);
                if (rec.Intersects(new Rectangle((int)x, (int)y, 40, 40)))
                {
                    colision = true;
                }
            }
            if (person.Intersects(new Rectangle((int)x, (int)y, 40, 40)))
            {
                colision = true;
            }
            return colision;
        }

        public void move(Keys k,Entidad e)
        {
            if(movimiento > 0)
            {
                switch (k)
                {
                    case Keys.Right:
                        if (!colisionMuro(e.GetPosicionX() + 40, e.GetPosicionY()))
                        {
                            e.SetPosicionX(e.GetPosicionX() + 40); 
                            movimiento--;
                        }
                        break;
                    case Keys.Left:
                        if (!colisionMuro(e.GetPosicionX() - 40, e.GetPosicionY()))
                        {
                            e.SetPosicionX(e.GetPosicionX() - 40);
                            movimiento--;
                        }
                        break;
                    case Keys.Down:
                        if (!colisionMuro(e.GetPosicionX(), e.GetPosicionY() + 40))
                        {
                            e.SetPosicionY(e.GetPosicionY() + 40);
                            movimiento--;
                        }
                        break;
                    case Keys.Up:
                        if (!colisionMuro(e.GetPosicionX(), e.GetPosicionY() - 40))
                        {
                            e.SetPosicionY(e.GetPosicionY() - 40);
                            movimiento--;
                        }
                        break;
                    default:
                        break;
                }
            }
        }

        public bool estado(Estado e) //Comprueba el estado actual
        {
            if(estadoActual == e)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void cambioOpcion(int num, ref int opcion)
        {
            if (opcion + num > MAXOPCION)
            {
                opcion = 0;
            }
            else if (opcion + num < 0)
            {
                opcion = MAXOPCION;
            }
            else
            {
                opcion += num;
            }
        }

        

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            tile = Content.Load<Texture2D>("img/Tile");
            personaje = Content.Load<Texture2D>("img/Warrior");
            esqueleto = Content.Load<Texture2D>("img/Skeleton");
            barbaro = Content.Load<Texture2D>("img/Barbarian");
            fuente = Content.Load<SpriteFont>("Fuente");
        }

        

        protected override void Update(GameTime gameTime)
        {
            int opc = 0;
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            lastKeyboardState = keyboardState;
            keyboardState = Keyboard.GetState();

            if (estado(Estado.menuInicio))
            {
                if (KeyPressed(Keys.Enter))
                {
                    switch (opcion)
                    {
                        case 0:
                            estadoActual = Estado.turnoJugador;
                            break;
                        case 1:
                            estadoActual = Estado.creacionPersonaje;
                            break;
                        case 2:
                            Exit();
                            break;
                        default:
                            break;
                    }
                }

                if (KeyPressed(Keys.Up))
                {
                    cambioOpcion(1, ref opcion);
                }

                if (KeyPressed(Keys.Down))
                {
                    cambioOpcion(-1, ref opcion);
                }
            }

            if (estado(Estado.creacionPersonaje))
            {
                output = "Nombre: " + input + "\nClase: ";
                if (KeyPressed(Keys.Right))
                {
                    cambioOpcion(1, ref opcion);
                }

                if (KeyPressed(Keys.Left))
                {
                    cambioOpcion(-1, ref opcion);
                }

                if (KeyPressed(Keys.Enter))
                {
                    estadoActual = Estado.menuInicio;
                }
            }
            if(!estado(Estado.creacionPersonaje) && !estado(Estado.menuInicio) && !estado(Estado.gameOver))
            {
                if (iniciativa < enemigos.Count)
                {
                    if (enemigos[iniciativa].GetHP() <= 0)
                    {
                        enemigos.Remove(enemigos[iniciativa]);
                    }
                    else if (enemigos[iniciativa].enRango(pj) && accion)
                    {
                        output = enemigos[iniciativa].Ataque(pj);
                        accion = false;
                    }
                    else if (movimiento > 0 && accion)
                    {
                        opc = rand.Next(1, 5);
                        switch (opc)
                        {
                            case 1:
                                move(Keys.Up, enemigos[iniciativa]);

                                break;
                            case 2:
                                move(Keys.Down, enemigos[iniciativa]);
                                //Thread.Sleep(200);
                                break;
                            case 3:
                                move(Keys.Left, enemigos[iniciativa]);
                                //Thread.Sleep(200);
                                break;
                            case 4:
                                move(Keys.Right, enemigos[iniciativa]);
                                //Thread.Sleep(200);
                                break;
                            default:
                                break;
                        }
                    }
                    else
                    {
                        accion = true;
                        iniciativa++;

                        Thread.Sleep(300);
                        if (iniciativa != enemigos.Count)
                        {
                            movimiento = enemigos[iniciativa].GetMovimiento();
                            nombreTurnoActual = enemigos[iniciativa].GetNombre();
                        }
                        else
                        {
                            movimiento = pj.GetMovimiento();
                            estadoActual = Estado.turnoJugador;
                            nombreTurnoActual = pj.GetNombre();
                        }

                    }

                }



                if (KeyPressed(Keys.E) && accion)
                {
                    if (estado(Estado.turnoJugador))
                    {
                        estadoActual = Estado.seleccionarCasilla;
                        cursor = pj.GetPosicion();
                    }
                    else if (estado(Estado.seleccionarCasilla))
                    {
                        estadoActual = Estado.turnoJugador;
                    }
                }// Cambia al estado de ataque o sale de el

                if (estado(Estado.seleccionarCasilla))
                {
                    if (KeyPressed(Keys.Right) || KeyPressed(Keys.D))
                        cursor.X += 40;

                    if (KeyPressed(Keys.Left) || KeyPressed(Keys.A))
                        cursor.X -= 40;

                    if (KeyPressed(Keys.Down) || KeyPressed(Keys.S))
                        cursor.Y += 40;

                    if (KeyPressed(Keys.Up) || KeyPressed(Keys.W))
                        cursor.Y -= 40;

                    if (KeyPressed(Keys.Enter))// TODO comprobar que la casilla esta ocupada
                    {
                        foreach (Enemigo e in enemigos)
                        {
                            if (cursor.Equals(e.GetPosicion()))
                            {
                                if (pj.enRango(e))
                                {
                                    output = pj.Ataque(e);
                                    if (e.GetHP() <= 0)
                                    {
                                        output += "\n" + e.GetNombre() + " ha sido derrotado.";
                                    }
                                    estadoActual = Estado.turnoJugador;
                                    accion = false;
                                }
                            }
                        }

                    }
                }  // Entradas de teclado durante secuencia de ataque 

                if (estado(Estado.turnoJugador))
                {
                    if (KeyPressed(Keys.Right) || KeyPressed(Keys.D))
                    {
                        move(Keys.Right, pj);
                    }

                    if (KeyPressed(Keys.Left) || KeyPressed(Keys.A))
                    {
                        move(Keys.Left, pj);
                    }

                    if (KeyPressed(Keys.Down) || KeyPressed(Keys.S))
                    {
                        move(Keys.Down, pj);
                    }

                    if (KeyPressed(Keys.Up) || KeyPressed(Keys.W))
                    {
                        move(Keys.Up, pj);
                    }

                    if (KeyPressed(Keys.Space))
                    {
                        estadoActual = Estado.turnoEnemigo;

                        accion = true;
                        iniciativa = 0;
                        nombreTurnoActual = enemigos[iniciativa].GetNombre();
                    }
                } // Acciones durante turno del jugador


                if (pj.GetHP() <= 0 || enemigos.Count == 0)
                {
                    estadoActual = Estado.gameOver;
                }// Acaba si llegamos a 0 HP o acabamos con todos los enemigos
            }
            

            if (estado(Estado.gameOver))
            {
                if (pj.GetHP() <= 0)
                {
                    output = "Has sido derrotado \n";
                }
                else
                {
                    output = "Victoria!\n";
                    pj.SetExpAcumulada(pj.GetExpAcumulada() + experiencia);
                    if (pj.GetExpAcumulada() >= 100)
                    {
                        output += "Has subido de nivel! Nivel:" + pj.GetNivel();
                        pj.SubidaNivel();
                        experiencia = 0;
                    }
                }
                
                output += "Pulsa Enter para volver al menu de inicio\nPulsa Espacio para salir";
                if (KeyPressed(Keys.Enter))
                {
                    pj.SetHP(pj.GetHpMax());
                    pj.GuardarPersonaje();
                    this.SetNuevaPartida(true);
                    Exit();
                    //Run game again
                }
                if (KeyPressed(Keys.Space))
                {
                    pj.SetHP(pj.GetHpMax());
                    pj.GuardarPersonaje();
                    this.SetNuevaPartida(false);
                    Exit();
                }
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(new Color(30, 30, 30));

            // TODO: Add your drawing code here
            _spriteBatch.Begin();
            if (estado(Estado.menuInicio))
            {
                _spriteBatch.DrawString(
                       fuente,
                       "PROYECTO RGP",
                       new Vector2(540, 150),
                       Color.Green);
                _spriteBatch.DrawString(
                        fuente,
                        "Nueva Partida",
                        new Vector2(540, 200),
                        opcion==0?Color.Yellow:Color.White);
                _spriteBatch.DrawString(
                        fuente,
                        "Crear Personaje(No implementado)",
                        new Vector2(540, 250),
                        opcion == 1 ? Color.Yellow : Color.White);
                _spriteBatch.DrawString(
                        fuente,
                        "Salir",
                        new Vector2(540, 300),
                        opcion == 2 ? Color.Yellow : Color.White);
                
            } 
            else if (estado(Estado.gameOver))
            {
                _spriteBatch.DrawString(
                        fuente,
                        output,
                        new Vector2(600, 300),
                        Color.White);
            }
            else if (estado(Estado.creacionPersonaje))
            {
                _spriteBatch.DrawString(
                        fuente,
                        output,
                        new Vector2(600, 300),
                        Color.White);
            }
            else
            {
                for (int i = 0; i < filas; i++)
                {
                    for (int j = 0; j < columnas; j++)
                    {
                        if (mapa[i][j] != 'X')
                            _spriteBatch.Draw(tile,
                                new Rectangle(j * 40, i * 40, 35, 35),
                                Color.Gray);
                    }
                }// Dibuja las casillas
                if (estadoActual == Estado.seleccionarCasilla)
                {
                    for (int i = 1; i <= pj.GetAlcanceAtq(); i++)
                    {

                        _spriteBatch.Draw(tile,
                                new Rectangle(pj.GetPosicionX(), pj.GetPosicionY(), 35, 35),
                                Color.Blue);

                        if (mapa[i][i] != 'X')
                            _spriteBatch.Draw(tile,
                                new Rectangle(pj.GetPosicionX() + (i * 40), pj.GetPosicionY(), 35, 35),
                                Color.Blue);
                        if (mapa[i][i] != 'X')
                            _spriteBatch.Draw(tile,
                                new Rectangle(pj.GetPosicionX() - (i * 40), pj.GetPosicionY(), 35, 35),
                                Color.Blue);
                        if (mapa[i][i] != 'X')
                            _spriteBatch.Draw(tile,
                                new Rectangle(pj.GetPosicionX(), pj.GetPosicionY() + (i * 40), 35, 35),
                                Color.Blue);
                        if (mapa[i][i] != 'X')
                            _spriteBatch.Draw(tile,
                                new Rectangle(pj.GetPosicionX(), pj.GetPosicionY() - (i * 40), 35, 35),
                                Color.Blue);
                        if (mapa[i][i] != 'X')
                            _spriteBatch.Draw(tile,
                                new Rectangle((int)cursor.X, (int)cursor.Y, 38, 38),
                                Color.Yellow);
                    }

                }//Dibujar alcance y cursor al atacar
                foreach (Enemigo e in enemigos)
                {
                    if (e.GetHP() > 0)
                    {
                        switch (e.GetNombre())
                        {
                            case "Esqueleto":
                                _spriteBatch.Draw(esqueleto,
                                            new Rectangle(e.GetPosicionX(), e.GetPosicionY(), 35, 35),
                                             Color.White);
                                break;
                            case "Barbaro":
                                _spriteBatch.Draw(barbaro,
                                            new Rectangle(e.GetPosicionX(), e.GetPosicionY(), 35, 35),
                                            Color.White);
                                break;
                            case "Arquero":
                                _spriteBatch.Draw(esqueleto,
                                            new Rectangle(e.GetPosicionX(), e.GetPosicionY(), 35, 35),
                                            Color.Red);
                                break;
                            default:
                                break;
                        }
                    }
                    
                    
                } // Dibuja los enemigos
                _spriteBatch.DrawString(fuente,
                        "Turno: " + nombreTurnoActual,
                        new Vector2(600, 600),
                        Color.Yellow);
                _spriteBatch.DrawString(fuente,
                        "Movimiento: " + movimiento,
                        new Vector2(850, 600),
                        Color.Yellow);
                _spriteBatch.DrawString(
                        fuente,
                        "HP: " + pj.GetHP(),
                        new Vector2(1000, 600),
                        Color.Yellow);
                _spriteBatch.DrawString(fuente,
                        "Controles:",
                        new Vector2(600, 660),
                        Color.Yellow);
                _spriteBatch.DrawString(fuente,
                        "        Mover: w,s,a,d        Atacar: e        Aceptar: enter        Pasar turno: espacio",
                        new Vector2(600, 680),
                        Color.Yellow);
                
                _spriteBatch.DrawString(fuente,
                    output,
                    new Vector2(100, 620),
                    Color.Yellow); // Dibuja el log de combate
                _spriteBatch.Draw(
                        personaje,
                        new Rectangle((int)pj.GetPosicionX(), (int)pj.GetPosicionY(), 35, 35),
                        Color.White);
            }
            
            _spriteBatch.End();

            base.Draw(gameTime);
        }

        public void SetNuevaPartida(bool b)
        {
            this.nuevaPartida = b;
        }

        public bool GetNuevaPartida()
        {
            return this.nuevaPartida;
        }
        
    }
}
