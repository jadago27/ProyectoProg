﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using Game1.Content.obj;
using System.Threading;
using System;
using System.IO;

namespace Game1
{
    public enum Estado { turnoJugador, turnoEnemigo, seleccionarCasilla, gameOver};
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        public Estado estadoActual= Estado.turnoJugador;
        KeyboardState keyboardState, lastKeyboardState;

        Texture2D tile;
        Texture2D personaje;
        Texture2D esqueleto;
        Texture2D barbaro;
        SpriteFont fuente;

        Personaje pj = new Personaje();
        Enemigo skel = new Enemigo(1, 20, 1, 1, "Skel", 5, 5, 6, 1, 6, 6);

        bool accion = true;
        int movimiento, filas = 720 / 40, columnas = 1280 / 40, iniciativa = 1, entidades = 0;
        string output="";
        

        Vector2 cursor = new Vector2(), posicion = new Vector2();


        string[] mapa =
        {
            "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
            "X                X             X",
            "X  P  S          X             X",
            "X                              X",
            "X           S                  X",
            "XXXXXX                         X",
            "X                X             X",
            "X                X             X",
            "X      XXXXXXXXXXXXXXXXX       X",
            "X                X             X",
            "X                X             X",
            "X                X             X",
            "X                              X",
            "X            S                 X",
            "X      X                       X",
            "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
            "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
            "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        };

        List<Rectangle> obstaculos = new List<Rectangle>();
        List<Rectangle> enemigos = new List<Rectangle>();
        List<Enemigo> esqueletos = new List<Enemigo>();

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            _graphics.PreferredBackBufferWidth = 1280;
            _graphics.PreferredBackBufferHeight = 720;
            _graphics.ApplyChanges();
            pj.CargarPersonaje("PJ");
            pj.SetIniciativa(entidades++);

            var rand = new Random();

            mapa=cargarMapa(rand.Next(1, 6));

            //pj = new Personaje(1, 0, "PJ", 10, 5, 1, 10, 10, 10);
            movimiento = pj.GetMovimiento();
            skel.SetPosicion(140, 60);
            //Guardamos las posiciones que aparecen en el mapa
            for (int i = 0; i < filas; i++)
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (mapa[i][j] == 'X')
                        obstaculos.Add(new Rectangle(j * 40, i * 40, 40, 40));
                    if (mapa[i][j] == 'S') 
                    {                    
                        enemigos.Add(new Rectangle(j * 40, i * 40, 40, 40));
                        esqueletos.Add(new Enemigo(esqueletos.Count + 1, 10, 1, 1, "Skel", 5, 2, 5, 1, 10, 4));
                        esqueletos[esqueletos.Count - 1].SetIniciativa(entidades++);
                        esqueletos[esqueletos.Count - 1].SetPosicion(j * 40, i * 40);
                    }
                    if (mapa[i][j] == 'P')
                    {
                        pj.SetPosicion(j*40, i*40);
                        posicion = pj.GetPosicion();
                        cursor = pj.GetPosicion();
                    }
                       
                }
            }
        }

        public string[] cargarMapa(int num)
        {
            StreamReader myFile;
            string[] lineas = new string[filas];
            string linea, fich="../../../Content/Mapas/mapa_"+num+".txt";
            if (File.Exists(fich))
            {
                myFile = File.OpenText(fich);
                for(int i=0;i<18;i++)
                {
                    linea = myFile.ReadLine();
                    if (linea != null)
                    {
                        linea = linea.Substring(1);
                        lineas[i]=(linea);
                    }
                } 
                myFile.Close();
            }
            return lineas;
        }

        bool KeyPressed(Keys key) // Nos permite realizar una accion solo una vez al pulsar una tecla
        {
            return keyboardState.IsKeyDown(key) && lastKeyboardState.IsKeyUp(key);
        }

        public bool colisionMuro( float x, float y) //Comprueba si se choca contra un muro
        {
            bool colision=false;
            foreach (Rectangle r in obstaculos)
            {
                if (r.Intersects(new Rectangle((int)x, (int)y, 40, 40)))
                {
                    colision = true;
                }
            }
            return colision;
        }

        public void move(Keys k)
        {
            if(movimiento > 0)
            {
                switch (k)
                {
                    case Keys.Right:
                        if (!colisionMuro(pj.GetPosicionX() + 40, pj.GetPosicionY()))
                        {
                            pj.SetPosicionX(pj.GetPosicionX() + 40); 
                            movimiento--;
                        }
                        break;
                    case Keys.Left:
                        if (!colisionMuro(pj.GetPosicionX() - 40, pj.GetPosicionY()))
                        {
                            pj.SetPosicionX(pj.GetPosicionX() - 40);
                            movimiento--;
                        }
                        break;
                    case Keys.Down:
                        if (!colisionMuro(pj.GetPosicionX(), pj.GetPosicionY() + 40))
                        {
                            pj.SetPosicionY(pj.GetPosicionY() + 40);
                            movimiento--;
                        }
                        break;
                    case Keys.Up:
                        if (!colisionMuro(pj.GetPosicionX(), pj.GetPosicionY() - 40))
                        {
                            pj.SetPosicionY(pj.GetPosicionY() - 40);
                            movimiento--;
                        }
                        break;
                    default:
                        break;
                }
            }
        }

        public int[] savePosicion(int x, int y) // Ayuda a guardar la posicion
        {
            int[] pos = { x, y };
            return pos;
        } 

        public bool estado(Estado e) //Comprueba el estado actual
        {
            if(estadoActual == e)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            tile = Content.Load<Texture2D>("img/Tile");
            personaje = Content.Load<Texture2D>("img/Warrior");
            esqueleto = Content.Load<Texture2D>("img/Skeleton");
            barbaro = Content.Load<Texture2D>("img/Barbarian");
            fuente = Content.Load<SpriteFont>("Fuente");
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            lastKeyboardState = keyboardState;
            keyboardState = Keyboard.GetState();
             
            if (KeyPressed(Keys.E) && accion && !estado(Estado.turnoEnemigo)) // Cambia al estado de ataque o sale de el
            {
                if(estado(Estado.turnoJugador))
                {
                    estadoActual = Estado.seleccionarCasilla;
                    cursor = pj.GetPosicion();
                }
                else if(estado(Estado.seleccionarCasilla))
                {
                    estadoActual = Estado.turnoJugador;
                }                
            }

            if (estado(Estado.seleccionarCasilla)) // Entradas de teclado durante secuencia de ataque 
            {
                if (KeyPressed(Keys.Right) || KeyPressed(Keys.D))
                    cursor.X+=40;

                if (KeyPressed(Keys.Left) || KeyPressed(Keys.A))
                    cursor.X -= 40;

                if (KeyPressed(Keys.Down) || KeyPressed(Keys.S))
                    cursor.Y += 40;

                if (KeyPressed(Keys.Up) || KeyPressed(Keys.W))
                    cursor.Y -= 40;

                if (KeyPressed(Keys.Enter))// TODO comprobar que la casilla esta ocupada
                {

                    
                    //if (cursor.Equals(skel.GetPosicion()))
                    //{
                        //if (pj.enRango(skel))
                        //{
                            output = pj.Ataque(skel);
                            estadoActual = Estado.turnoJugador;
                            accion = false;

                        //}
                    //}
                }
            }

            if (estado(Estado.turnoJugador)) 
            {
                if (KeyPressed(Keys.Right) || KeyPressed(Keys.D))
                {
                    move(Keys.Right);
                }

                if (KeyPressed(Keys.Left) || KeyPressed(Keys.A))
                {
                    move(Keys.Left);
                }

                if (KeyPressed(Keys.Down) || KeyPressed(Keys.S))
                {
                    move(Keys.Down);
                }

                if (KeyPressed(Keys.Up) || KeyPressed(Keys.W))
                {
                    move(Keys.Up);
                }

                if (KeyPressed(Keys.Space))
                {
                    estadoActual = Estado.turnoEnemigo;
                    accion = true;
                }
            } // Acciones durante turno del jugador

            if (estado(Estado.turnoEnemigo))
            {
                foreach(Enemigo e in esqueletos)
                {
                    
                    e.SetPosicionX(e.GetPosicionX() + 40);
                }
                if(pj.GetPosicionX().Equals(skel.GetPosicionX()) || pj.GetPosicionY().Equals(skel.GetPosicionY()))
                {
                    if (pj.GetPosicionX().Equals(skel.GetPosicionX() - 40) || pj.GetPosicionX().Equals(skel.GetPosicionX() + 40))
                    {
                        output = skel.Ataque(pj);
                    } 
                    else if(pj.GetPosicionX().Equals(skel.GetPosicionX() - 40) || pj.GetPosicionX().Equals(skel.GetPosicionX() + 40))
                    {
                        output = skel.Ataque(pj);
                    }
                }
                estadoActual = Estado.turnoJugador;
                movimiento = pj.GetMovimiento();
                accion = true;
            }


            if (pj.GetHP()==0 || enemigos.Count == 0) // Acaba si llegamos a 0 HP o acabamos con todos los enemigos
            {
                estadoActual = Estado.gameOver;
                output = "Game Over\nPulsa enter para salir";
            }

            //if (estado(Estado.gameOver))
            //{
                if (KeyPressed(Keys.K))
                {
                    pj.GuardarPersonaje();
                    Exit();
                }
            //}

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(new Color(30, 30, 30));

            // TODO: Add your drawing code here
            _spriteBatch.Begin();
            for (int i = 0; i < filas; i++)  
            {
                for (int j = 0; j < columnas; j++)
                {
                    if (mapa[i][j] != 'X')
                        _spriteBatch.Draw(tile,
                            new Rectangle(j * 40, i * 40, 37, 37),
                            Color.Gray);
                }
            }// Dibuja las casillas
            if (estadoActual == Estado.seleccionarCasilla)
            {
                    for (int i = 1; i <= pj.GetAlcanceAtq(); i++)
                    {

                    _spriteBatch.Draw(tile,
                            new Rectangle(pj.GetPosicionX(), pj.GetPosicionY(), 35 ,35),
                            Color.Blue);

                        if (mapa[i][i] != 'X')
                            _spriteBatch.Draw(tile,
                                new Rectangle(pj.GetPosicionX() + (i*40), pj.GetPosicionY(), 35, 35),
                                Color.Blue);
                        if (mapa[i][i] != 'X')
                            _spriteBatch.Draw(tile,
                                new Rectangle(pj.GetPosicionX() - (i * 40), pj.GetPosicionY(), 35, 35),
                                Color.Blue);
                        if (mapa[i][i] != 'X')
                            _spriteBatch.Draw(tile,
                                new Rectangle(pj.GetPosicionX(), pj.GetPosicionY() + (i * 40), 35, 35),
                                Color.Blue);
                        if (mapa[i][i] != 'X')
                            _spriteBatch.Draw(tile,
                                new Rectangle(pj.GetPosicionX(), pj.GetPosicionY() - (i * 40), 35, 35),
                                Color.Blue);
                        if (mapa[i][i] != 'X')
                            _spriteBatch.Draw(tile,
                                new Rectangle((int)cursor.X, (int)cursor.Y, 38, 38),
                                Color.Yellow);
                }

            }//Dibujar alcance y cursor al atacar

            foreach (Enemigo e in esqueletos) 
            {
                _spriteBatch.Draw(esqueleto,
                    new Rectangle((int)e.GetPosicionX(), (int)e.GetPosicionY(), 35, 35),
                    Color.White);
            } // Dibuja los enemigos

            _spriteBatch.DrawString(fuente,
                "Movimiento: " + movimiento,
                new Vector2(850, 600),
                Color.Yellow); // Dibuja el contador de movimiento
            _spriteBatch.DrawString(fuente,
                "HP: " + skel.GetHP(),
                new Vector2(1000, 600),
                Color.Yellow); // Dibuja el hp actual
            _spriteBatch.DrawString(fuente, 
                    output, 
                    new Vector2(100, 600),
                    Color.Yellow); // Dibuja el log de combate
            _spriteBatch.Draw(
                personaje, 
                new Rectangle((int)pj.GetPosicionX(), (int)pj.GetPosicionY(), 35, 35),
                Color.White); // Dibuja al personaje
            _spriteBatch.End();

            base.Draw(gameTime);
        }

        
    }
}
